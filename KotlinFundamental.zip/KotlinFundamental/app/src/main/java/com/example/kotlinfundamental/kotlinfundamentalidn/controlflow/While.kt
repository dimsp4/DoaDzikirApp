fun main() {
    var dzikir = 7
    // while (condition) { statement }
    while (dzikir >= 1) {
        println("Subhanallahu Walhamdulillah walaa ilaha ilallah wallahu akbar")
        dzikir--
    }

    var tasbih = 1
    // do { statement } while (condition)
    do {
        println("Subhanallahu Walhamdulillah walaa ilaha ilallah wallahu akbar")
        tasbih++
    } while (tasbih <= 7)
}