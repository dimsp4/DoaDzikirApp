fun main() {
    var angka = 9
    // increment
    println(angka++)
    println(++angka)

    // decrement
    println(angka--)
    println(--angka)
}