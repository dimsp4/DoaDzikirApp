package com.example.kotlinfundamental.kotlinfundamentalidn.oop

fun main(){
    val animal = Animal()
    animal.info() //bisa jalan karna modifiernya 'public'
    animal.umur // error karena
}