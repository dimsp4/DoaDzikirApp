fun main() {
    var a = 9 // a bernilai 9
    var b = 10 // b bernilai 10

    a += b // berarti a = a + b
    println(a) // sekarang a bernilai 19

    a -= b // berarti a = a - b
    println(a) // sekarang a bernilai 9

    b -= a // berarti b = b - a
    println(b) // maka b bernilai 1

    b *= 5 // berarti b = b * 5
    println(b)
}