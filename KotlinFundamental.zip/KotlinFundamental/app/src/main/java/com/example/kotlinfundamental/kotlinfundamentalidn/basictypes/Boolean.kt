fun main() {
    val kece = true
    val kucel = false
    println("Yusril kece is $kece, kucel is $kucel")

    val isOpen = "PPDB IDN is open."
    val isClosed = "PPDB IDN is close."

    if (true) println("$isOpen Program opened!") else println("$isClosed Program closed!")
}