fun main() {
    var a = 9 // a bernilai 9
    var b = 10 // b bernilai 10

    println("a = $a")
    println("b = $b")

    // operator pembanding
    println("a > b = ${a > b}")
    println("a < b = ${a < b}")
    println("a >= b = ${a >= b}")
    println("a <= b = ${a <= b}")
    println("a == b = ${a == b}")
    println("a != b = ${a != b}")
}